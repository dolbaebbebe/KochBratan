MipaApps — рендер MP4 на телефоне через GitHub Codespaces

Что делает:
- запускает исходный React/Vite-проект;
- записывает анимацию браузера в течение 66,6 секунды;
- конвертирует запись в MP4 1024x576 (H.264).

Шаги в Codespaces (Ubuntu):
1. Создай пустой репозиторий GitHub и загрузи туда содержимое этого ZIP.
2. Открой репозиторий -> Code -> Codespaces -> Create codespace.
3. В терминале Codespaces выполни:

   sudo apt-get update && sudo apt-get install -y ffmpeg
   npm install
   npx playwright install --with-deps chromium
   npm run render

4. Подожди завершения рендера. В корне проекта появится MipaApps.mp4.
5. В панели Files найди MipaApps.mp4, открой меню файла и скачай его на телефон.

Важно:
- Не закрывай Codespace, пока идёт рендер.
- Рендер длится примерно 67 секунд плюс время кодирования.
- Если лимит Codespaces исчерпан, запуск может быть недоступен.
- Видео записывается с длительностью около 66,6 с и размером 1024x576.
