import { chromium } from "playwright";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";

const root = process.cwd();
const output = path.join(root, "MipaApps.mp4");
const temp = await mkdtemp(path.join(tmpdir(), "mipa-render-"));
const server = spawn("npm", ["run", "dev", "--", "--host", "127.0.0.1"], {
  cwd: root, stdio: "inherit", shell: process.platform === "win32"
});
let browser;
try {
  let ready = false;
  for (let i = 0; i < 90; i++) {
    try { const r = await fetch("http://127.0.0.1:5173"); if (r.ok) { ready = true; break; } } catch {}
    await delay(1000);
  }
  if (!ready) throw new Error("Vite server did not start on port 5173.");
  browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const context = await browser.newContext({
    viewport: { width: 1024, height: 576 }, deviceScaleFactor: 1,
    recordVideo: { dir: temp, size: { width: 1024, height: 576 } }
  });
  const page = await context.newPage();
  const video = page.video();
  await page.goto("http://127.0.0.1:5173", { waitUntil: "networkidle" });
  await page.addStyleTag({ content: "#root > div > div:last-child { display: none !important; }" });
  await page.evaluate(() => window.dispatchEvent(new Event("resize")));
  console.log("Rendering the 66.6-second video. Keep this process running...");
  await page.waitForTimeout(66300);
  await context.close();
  const webm = path.join(temp, "capture.webm");
  await video.saveAs(webm);
  await new Promise((resolve, reject) => {
    const ff = spawn("ffmpeg", ["-y", "-i", webm, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", output], { stdio: "inherit" });
    ff.on("error", reject);
    ff.on("close", code => code === 0 ? resolve() : reject(new Error("ffmpeg exited with code " + code)));
  });
  console.log("Done: " + output);
} finally {
  if (browser) await browser.close().catch(() => {});
  server.kill("SIGTERM");
  await rm(temp, { recursive: true, force: true });
}
