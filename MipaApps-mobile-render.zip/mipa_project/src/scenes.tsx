import React from "react";
import { AppIcon, BlockIcon, BrandLogo, BRAND, Bullet, Card, Grid, Phone, TgMark } from "./ui";

export type Scene = { start: number; end: number; render: () => React.ReactNode; group?: string };

const pastel = "linear-gradient(135deg,#e4f2ff 0%,#fbe7f2 55%,#ebe3ff 100%)";
const skyPink = "linear-gradient(150deg,#c4e6ff 0%,#f8d9e9 55%,#d9ccff 100%)";
const wood = "repeating-linear-gradient(90deg,#795034 0 48px,#694328 48px 51px,#81563a 51px 103px,#694328 103px 106px)";

const Full = ({ bg, children, style }: { bg: string; children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{ position: "absolute", inset: 0, background: bg, overflow: "hidden", ...style }}>{children}</div>
);

const games: (string | [string, string])[] = [
  ["mc", "Minecraft"],
  ["terraria", "Terraria"],
  ["geo", "Geometry Dash"],
  ["plague", "Plague Inc."],
];

const homeScreen: (string | [string, string])[] = [
  ["calendar", "Календарь"],
  ["photo", "Фото"],
  ["cam", "Камера"],
  ["safari", "Safari"],
  ["messages", "Сообщения"],
  ["appstore", "App Store"],
  ["clock", "Часы"],
  ["settings", "Настройки"],
  ...games,
];

const Split = ({ bg, phone, children }: { bg: string; phone: React.ReactNode; children: React.ReactNode }) => (
  <Full bg={bg}>
    <div className="sl" style={{ position: "absolute", left: 90, top: 50 }}>
      <div className="float">{phone}</div>
    </div>
    <div style={{ position: "absolute", left: 420, right: 50, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", gap: 18 }}>
      {children}
    </div>
  </Full>
);

function CloudDownload({ size = 22 }: { size?: number }) {
  return (
    <svg aria-label="Загрузить из облака" viewBox="0 0 32 32" width={size} height={size} fill="none" style={{ display: "block", flexShrink: 0 }}>
      <path d="M9.3 23.5a6.1 6.1 0 0 1-.8-12.1 8.3 8.3 0 0 1 15.8 2.2 5.1 5.1 0 0 1-.7 10H9.3Z" stroke="#2780f5" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M16 13.7v8m-3.3-3.2L16 22l3.3-3.5" stroke="#2780f5" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const StepScene = ({ n, title, screen }: { n: number; title: string; screen: React.ReactNode }) => (
  <Split bg={pastel} phone={<Phone className="drift" w={250} h={476}>{screen}</Phone>}>
    <div className="fu" style={{ fontSize: 30, fontWeight: 700, color: "#6b6b85" }}>Шаг {n} из 4</div>
    <div className="fu" style={{ fontSize: 58, fontWeight: 800, color: "#111", lineHeight: 1.06, animationDelay: ".2s" }}>{title}</div>
    <div className="grow" style={{ height: 8, width: 300, borderRadius: 4, background: "#2f7bff", animationDelay: ".6s" }} />
  </Split>
);

function AppListScreen() {
  return (
    <div style={{ padding: "50px 14px 0", color: "#171a21" }}>
      <div style={{ fontSize: 17, fontWeight: 800, marginBottom: 9 }}>Приложения</div>
      <div style={{ fontSize: 10, color: "#818796", marginBottom: 5 }}>Игры</div>
      {games.map(([k, name]) => (
        <div key={k} style={{ display: "flex", alignItems: "center", gap: 10, minHeight: 69, borderBottom: "1px solid #e4e7ed" }}>
          <AppIcon k={k} size={42} showLabel={false} />
          <span style={{ flex: 1, minWidth: 0, fontSize: 13, fontWeight: 650, lineHeight: 1.2 }}>{name}</span>
          <CloudDownload size={21} />
        </div>
      ))}
    </div>
  );
}

function ChannelScene() {
  return (
    <Split bg={pastel} phone={<Phone dark w={250} h={476}><Grid keys={games} size={50} dark gap={20} cols={2} padding="58px 14px 0" /></Phone>}>
      <div className="float-soft">
        <Card className="sr" style={{ padding: 28, animationDelay: ".25s" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
            <TgMark size={58} />
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 21, fontWeight: 600, color: "#656779" }}>Telegram-канал</div>
              <div style={{ fontSize: 32, lineHeight: 1.15, fontWeight: 800, color: "#15151d" }}>{BRAND}</div>
            </div>
            <BrandLogo size={54} style={{ marginLeft: "auto" }} />
          </div>
          <div style={{ height: 1, background: "#e8e7ef", margin: "0 0 18px" }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Bullet color="#34c759">Платные игры бесплатно</Bullet>
            <Bullet color="#2f7bff">Данные аккаунта — в канале</Bullet>
            <Bullet color="#ff9f0a">Инструкция по установке</Bullet>
          </div>
        </Card>
      </div>
    </Split>
  );
}

function InfoScene() {
  return (
    <Split bg={pastel} phone={<Phone dark w={250} h={476}><Grid keys={games} size={50} dark gap={20} cols={2} padding="58px 14px 0" /></Phone>}>
      <div className="float-soft">
        <Card className="sr" style={{ padding: 36, animationDelay: ".2s" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <TgMark size={68} />
            <div style={{ fontSize: 29, fontWeight: 700, color: "#252632" }}>Telegram-канал</div>
          </div>
          <div style={{ height: 1, background: "#e8e7ef", margin: "26px 0" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <BrandLogo size={76} />
            <div style={{ fontSize: 46, fontWeight: 800, letterSpacing: -.8, color: "#15151d" }}>{BRAND}</div>
          </div>
        </Card>
      </div>
    </Split>
  );
}

export const SCENES: Scene[] = [
  // 0:00-0:03
  {
    start: 0, end: 3,
    render: () => (
      <Full bg={pastel}>
        <div className="pop" style={{ position: "absolute", left: 92, top: 148 }}><BlockIcon size={280} /></div>
        <div style={{ position: "absolute", left: 440, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", gap: 2, fontSize: 70, fontWeight: 800, lineHeight: 1.1, color: "#16161f" }}>
          <div className="sr">Как скачать</div>
          <div className="sr" style={{ color: "#3fa535", animationDelay: ".25s" }}>Minecraft</div>
          <div className="sr" style={{ animationDelay: ".5s" }}>на <span style={{ color: "#2f7bff" }}>iPhone</span></div>
        </div>
      </Full>
    ),
  },
  // 0:03-0:06
  {
    start: 3, end: 6,
    render: () => (
      <Full bg={skyPink} style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="hello" style={{ fontSize: 150, fontWeight: 800, color: "#000" }}>Привет!</div>
      </Full>
    ),
  },
  // 0:06-0:10
  {
    start: 6, end: 10,
    render: () => (
      <Full bg={pastel} style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
        <div className="fu" style={{ fontSize: 76, fontWeight: 800, color: "#111" }}>Два рабочих способа</div>
        <div className="fu" style={{ fontSize: 38, fontWeight: 600, color: "#44445a", animationDelay: ".3s" }}>скачать платные игры на iPhone</div>
        <div className="pop" style={{ marginTop: 22, animationDelay: ".7s" }}><BrandLogo size={110} /></div>
      </Full>
    ),
  },
  // 0:10-0:15
  {
    start: 10, end: 15,
    render: () => (
      <Full bg={wood}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 30, display: "flex", justifyContent: "center", gap: 22 }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="fu" style={{ animationDelay: `${i * 0.22}s` }}>
              <Phone w={170} h={350} dark>
                <Grid keys={games} size={43} dark gap={18} cols={2} padding="60px 10px 0" />
              </Phone>
            </div>
          ))}
        </div>
        <div className="sl" style={{ position: "absolute", left: 52, bottom: 35, fontSize: 48, fontWeight: 800, color: "#fff", textShadow: "0 3px 12px rgba(0,0,0,.5)", animationDelay: ".8s" }}>общий аккаунт</div>
        <div className="pop" style={{ position: "absolute", right: 52, bottom: 26, display: "flex", alignItems: "center", gap: 14, animationDelay: "1s" }}>
          <BrandLogo size={70} />
          <span style={{ fontSize: 26, fontWeight: 800, color: "#fff", textShadow: "0 2px 8px rgba(0,0,0,.45)" }}>{BRAND}</span>
        </div>
      </Full>
    ),
  },
  // 0:15-0:21
  {
    start: 15, end: 21,
    render: () => (
      <Split bg={pastel} phone={<Phone w={250} h={476}><AppListScreen /></Phone>}>
        <div className="fu" style={{ fontSize: 50, fontWeight: 800, lineHeight: 1.08, color: "#111" }}>
          <span style={{ color: "#348e35" }}>Minecraft</span> есть —<br />можно установить
        </div>
        <div className="fu" style={{ background: "#ffe98a", borderRadius: 20, padding: "20px 24px", fontSize: 24, lineHeight: 1.32, fontWeight: 600, color: "#3d3200", boxShadow: "0 12px 28px rgba(200,160,0,.25)", animationDelay: ".6s" }}>
          Следуй инструкции из канала — так игра установится без ошибок
        </div>
      </Split>
    ),
  },
  // 0:21-0:30
  { start: 21, end: 30, group: "channel", render: () => <ChannelScene /> },
  // 0:30-0:34: same phone and channel card, carried through as one continuous shot.
  { start: 30, end: 34, group: "channel", render: () => <ChannelScene /> },
  // 0:34-0:45
  { start: 34, end: 45, render: () => <InfoScene /> },
  // 0:45-0:49
  {
    start: 45, end: 49,
    render: () => (
      <StepScene n={1} title="Открыть App Store" screen={
        <div style={{ position: "relative" }}>
          <Grid keys={homeScreen} size={34} gap={12} cols={3} padding="52px 10px 0" />
          <div className="tp" style={{ position: "absolute", left: 166, top: 105, width: 48, height: 48, borderRadius: 13, border: "3px solid #2f7bff" }} />
        </div>} />
    ),
  },
  // 0:49-0:53
  {
    start: 49, end: 53,
    render: () => (
      <StepScene n={2} title="Войти в аккаунт" screen={
        <div style={{ padding: "54px 17px 0", textAlign: "center", color: "#171a21" }}>
          <div style={{ fontSize: 17, fontWeight: 800, marginBottom: 18 }}>Аккаунт Apple</div>
          <div style={{ width: 62, height: 62, borderRadius: "50%", background: "linear-gradient(145deg,#83c8ff,#5176d8)", margin: "0 auto 17px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg viewBox="0 0 48 48" width="38" height="38" aria-hidden="true"><circle cx="24" cy="16" r="8" fill="#fff" /><path d="M8 42c1-9 7-14 16-14s15 5 16 14" fill="#fff" /></svg>
          </div>
          <div style={{ background: "#fff", border: "1px solid #e1e4ec", borderRadius: 11, padding: 12, fontSize: 13, textAlign: "left", marginBottom: 8 }}>Apple ID</div>
          <div style={{ background: "#fff", border: "1px solid #e1e4ec", borderRadius: 11, padding: 12, fontSize: 13, textAlign: "left", marginBottom: 13 }}>Пароль</div>
          <div style={{ background: "#2f7bff", color: "#fff", borderRadius: 11, padding: 11, fontWeight: 700, fontSize: 13 }}>Войти</div>
        </div>} />
    ),
  },
  // 0:53-0:56
  {
    start: 53, end: 56,
    render: () => (
      <StepScene n={3} title="Покупки → облачко" screen={
        <div style={{ padding: "52px 12px 0", color: "#171a21" }}>
          <div style={{ fontSize: 17, fontWeight: 800, marginBottom: 8 }}>Покупки</div>
          {games.map(([k, name]) => (
            <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 67, borderBottom: "1px solid #e4e7ed" }}>
              <AppIcon k={k} size={37} showLabel={false} />
              <span style={{ flex: 1, minWidth: 0, fontSize: 12, fontWeight: 650, lineHeight: 1.15 }}>{name}</span>
              <CloudDownload size={20} />
            </div>
          ))}
        </div>} />
    ),
  },
  // 0:56-0:59
  {
    start: 56, end: 59,
    render: () => (
      <StepScene n={4} title="Игра на главном экране" screen={<Grid keys={homeScreen} size={34} gap={12} cols={3} padding="52px 10px 0" />} />
    ),
  },
  // 0:59-1:06.6
  {
    start: 59, end: 66.6,
    render: () => (
      <Full bg={pastel} style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <div className="fu" style={{ display: "flex", alignItems: "center", gap: 20, animationDelay: ".15s" }}>
          <BrandLogo size={96} />
          <div style={{ fontSize: 62, fontWeight: 800, letterSpacing: -1.4, color: "#111" }}>{BRAND}</div>
        </div>
        <div className="fu" style={{ fontSize: 29, fontWeight: 600, color: "#44445a", marginTop: 17, animationDelay: ".4s" }}>Раздачи аккаунтов и платный доступ</div>
        <div style={{ display: "flex", gap: 24, marginTop: 31 }}>
          {["Telegram-канал", "Telegram-бот"].map((title, i) => (
            <Card key={title} className="fu" style={{ width: 325, minHeight: 86, padding: "16px 22px", display: "flex", alignItems: "center", gap: 16, animationDelay: `${.7 + i * .25}s` }}>
              <TgMark size={54} />
              <span style={{ fontSize: 25, fontWeight: 750, color: "#191923" }}>{title}</span>
            </Card>
          ))}
        </div>
        <div className="pop" style={{ marginTop: 31, background: "#09090c", color: "#fff", fontSize: 26, fontWeight: 700, padding: "17px 54px", borderRadius: 40, animationDelay: "1.2s" }}>Ссылка в описании</div>
      </Full>
    ),
  },
];

export const DURATION = 66.6;
