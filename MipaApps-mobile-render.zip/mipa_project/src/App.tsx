import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { DURATION, SCENES } from "./scenes";
import { BRAND } from "./ui";

const W = 1024;
const H = 576;

function fmt(t: number) {
  const m = Math.floor(t / 60);
  const s = (t % 60).toFixed(1);
  return `${m}:${s.padStart(4, "0")}`;
}

export default function App() {
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [scale, setScale] = useState(1);
  const wrap = useRef<HTMLDivElement>(null);
  const last = useRef<number | null>(null);

  useLayoutEffect(() => {
    const fit = () => {
      const el = wrap.current;
      if (!el) return;
      setScale(Math.min(el.clientWidth / W, el.clientHeight / H));
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  useEffect(() => {
    if (!playing) {
      last.current = null;
      return;
    }
    let raf = 0;
    const tick = (now: number) => {
      if (last.current != null) {
        const dt = (now - last.current) / 1000;
        setTime((t) => (t + dt >= DURATION ? 0 : t + dt));
      }
      last.current = now;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing]);

  const idx = Math.max(0, SCENES.findIndex((s) => time >= s.start && time < s.end));
  const scene = SCENES[idx];

  return (
    <div className="flex h-full flex-col bg-[#0b0b12] text-white">
      <div ref={wrap} className="flex min-h-0 flex-1 items-center justify-center overflow-hidden">
        <div style={{ width: W * scale, height: H * scale }}>
          <div style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: "top left", position: "relative", overflow: "hidden", borderRadius: 8, background: "linear-gradient(135deg,#e4f2ff 0%,#fbe7f2 55%,#ebe3ff 100%)" }}>
            <div key={scene.group ?? idx} style={{ position: "absolute", inset: 0 }} className="fi">
              {scene.render()}
            </div>
            <div style={{ position: "absolute", right: 16, top: 12, fontSize: 15, fontWeight: 700, color: "rgba(20,20,40,.52)", textShadow: "0 1px 3px rgba(255,255,255,.65)", zIndex: 20 }}>{BRAND}</div>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3 px-4 py-3">
        <button onClick={() => setPlaying((p) => !p)} className="w-20 rounded-lg bg-violet-600 px-3 py-1.5 text-sm font-semibold hover:bg-violet-500">
          {playing ? "Пауза" : "Играть"}
        </button>
        <span className="w-24 text-sm tabular-nums text-white/70">
          {fmt(time)} / {fmt(DURATION)}
        </span>
        <input
          type="range"
          min={0}
          max={DURATION}
          step={0.1}
          value={time}
          onChange={(e) => {
            setTime(parseFloat(e.target.value));
          }}
          className="flex-1 accent-violet-500"
        />
        <span className="hidden w-28 text-right text-xs text-white/50 sm:block">Сцена {idx + 1}/{SCENES.length}</span>
      </div>
    </div>
  );
}
