import React from "react";

export const BRAND = "@MipaApps";

const GAME_ART: Record<string, { src: string; name: string }> = {
  mc: { src: "/icons/minecraft.jpg", name: "Minecraft" },
  terraria: { src: "/icons/terraria.jpg", name: "Terraria" },
  geo: { src: "/icons/geometry-dash.jpg", name: "Geometry Dash" },
  plague: { src: "/icons/plague-inc.jpg", name: "Plague Inc." },
};

const SYSTEM_APPS: Record<string, { name: string; colors: [string, string] }> = {
  mail: { name: "Почта", colors: ["#62c9ff", "#1671df"] },
  cam: { name: "Камера", colors: ["#606a78", "#202935"] },
  photo: { name: "Фото", colors: ["#fff", "#f4f5fb"] },
  clock: { name: "Часы", colors: ["#414854", "#10141c"] },
  calendar: { name: "Календарь", colors: ["#fff", "#f6f7fa"] },
  safari: { name: "Safari", colors: ["#5cd3ff", "#1261e8"] },
  messages: { name: "Сообщения", colors: ["#6fe084", "#21a842"] },
  music: { name: "Музыка", colors: ["#ff7bb2", "#d92870"] },
  appstore: { name: "App Store", colors: ["#48c8ff", "#1874e8"] },
  settings: { name: "Настройки", colors: ["#bdc4cf", "#657184"] },
  tg: { name: "Telegram", colors: ["#fff", "#edf8ff"] },
};

/** The M mark is intentionally separate from the @MipaApps wordmark. */
export function BrandLogo({ size = 80, className = "", style }: { size?: number; className?: string; style?: React.CSSProperties }) {
  return (
    <div
      role="img"
      aria-label="Логотип MipaApps: буква M"
      className={className}
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.22,
        background: "linear-gradient(145deg,#8754ed,#6834c8)",
        boxShadow: "0 8px 22px rgba(91,47,176,.3)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#fff",
        fontWeight: 800,
        fontFamily: "Arial, Helvetica, sans-serif",
        fontSize: size * 0.67,
        lineHeight: 1,
        letterSpacing: -size * 0.04,
        flexShrink: 0,
        ...style,
      }}
    >
      M
    </div>
  );
}

/** The Minecraft artwork is the real App Store icon, not a generated block. */
export function BlockIcon({ size = 200, style, className = "" }: { size?: number; style?: React.CSSProperties; className?: string }) {
  return (
    <img
      src={GAME_ART.mc.src}
      alt="Minecraft"
      className={className}
      draggable={false}
      style={{ width: size, height: size, objectFit: "cover", borderRadius: size * 0.2, boxShadow: "0 14px 34px rgba(0,0,0,.22)", ...style }}
    />
  );
}

function SystemGlyph({ name }: { name: string }) {
  const white = { fill: "none", stroke: "#fff", strokeWidth: 4, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (name) {
    case "mail":
      return <svg viewBox="0 0 64 64" width="70%" height="70%"><rect x="11" y="17" width="42" height="30" rx="5" fill="#fff" /><path d="m13 20 19 15 19-15" fill="none" stroke="#2c8be9" strokeWidth="3" /></svg>;
    case "cam":
      return <svg viewBox="0 0 64 64" width="72%" height="72%"><path d="M10 21h10l4-6h16l4 6h10a4 4 0 0 1 4 4v22H6V25a4 4 0 0 1 4-4" fill="#d9e0e9" /><circle cx="32" cy="34" r="11" fill="#283242" stroke="#fff" strokeWidth="3" /><circle cx="32" cy="34" r="5" fill="#6ad2ff" /></svg>;
    case "photo":
      return <svg viewBox="0 0 64 64" width="78%" height="78%"><path d="M32 31C20 32 12 24 17 16c4-7 13-5 16 5z" fill="#ff554e" /><path d="M33 31c-1-12 7-20 15-15 7 4 5 13-5 16z" fill="#ffb83e" /><path d="M33 32c12-1 20 7 15 15-4 7-13 5-16-5z" fill="#74c94b" /><path d="M32 33c1 12-7 20-15 15-7-4-5-13 5-16z" fill="#4eabea" /><path d="M31 31c-9-8-8-18 1-20 8-2 13 6 9 17z" fill="#a667df" /></svg>;
    case "clock":
      return <svg viewBox="0 0 64 64" width="72%" height="72%"><circle cx="32" cy="32" r="23" fill="#fff" /><circle cx="32" cy="32" r="19" fill="none" stroke="#cbd1db" strokeWidth="1.5" /><path d="M32 17v16l11 7" fill="none" stroke="#1d2632" strokeWidth="3" strokeLinecap="round" /><path d="M19 10h26" stroke="#cbd1db" strokeWidth="3" strokeLinecap="round" /></svg>;
    case "calendar":
      return <svg viewBox="0 0 64 64" width="72%" height="72%"><rect x="10" y="12" width="44" height="42" rx="7" fill="#fff" /><path d="M10 20a8 8 0 0 1 8-8h28a8 8 0 0 1 8 8v6H10z" fill="#f04b54" /><path d="M21 9v10M43 9v10" stroke="#fff" strokeWidth="3" strokeLinecap="round" /><text x="32" y="45" textAnchor="middle" fontSize="22" fontWeight="700" fill="#252b35">12</text></svg>;
    case "safari":
      return <svg viewBox="0 0 64 64" width="74%" height="74%"><circle cx="32" cy="32" r="24" fill="#fff" /><circle cx="32" cy="32" r="19" fill="none" stroke="#91d8fa" strokeWidth="2" /><path d="m42 19-6 16-14 10 6-16z" fill="#f04550" /><path d="m36 35 6-16-14 10z" fill="#2d74e8" /><circle cx="32" cy="32" r="2.4" fill="#24354d" /></svg>;
    case "messages":
      return <svg viewBox="0 0 64 64" width="73%" height="73%"><path d="M11 17a8 8 0 0 1 8-8h26a8 8 0 0 1 8 8v20a8 8 0 0 1-8 8H29L17 55v-10a8 8 0 0 1-6-8z" fill="#fff" /><path d="M21 25h22M21 33h16" stroke="#41bf5e" strokeWidth="3" strokeLinecap="round" /></svg>;
    case "music":
      return <svg viewBox="0 0 64 64" width="68%" height="68%"><path d="M40 13v28a8 8 0 1 1-4-7V19l18-4v21a8 8 0 1 1-4-7V10z" fill="#fff" /></svg>;
    case "appstore":
      return <svg viewBox="0 0 64 64" width="72%" height="72%"><path d="m20 48 22-37M16 48h37M27 22l17 28M12 48h40" {...white} strokeWidth="4.4" /></svg>;
    case "settings":
      return <svg viewBox="0 0 64 64" width="74%" height="74%"><path d="M32 13v5m0 28v5M13 32h5m28 0h5M18.6 18.6l3.6 3.6m19.6 19.6 3.6 3.6m0-26.8-3.6 3.6m-19.6 19.6-3.6 3.6" stroke="#fff" strokeWidth="6" strokeLinecap="round" /><circle cx="32" cy="32" r="14" fill="none" stroke="#fff" strokeWidth="6" /><circle cx="32" cy="32" r="5" fill="#eef1f6" /></svg>;
    default:
      return <svg viewBox="0 0 64 64" width="70%" height="70%"><rect x="12" y="12" width="40" height="40" rx="10" fill="#fff" /></svg>;
  }
}

export function AppIcon({ k, size = 40, label, dark, showLabel = true }: { k: string; size?: number; label?: string; dark?: boolean; showLabel?: boolean }) {
  const game = GAME_ART[k];
  const system = SYSTEM_APPS[k];
  const iconName = label || game?.name || system?.name || "";
  const colors = system?.colors || ["#1b2638", "#101622"];
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, minWidth: 0 }}>
      <div style={{ width: size, height: size, borderRadius: size * 0.23, overflow: "hidden", flexShrink: 0, background: `linear-gradient(145deg,${colors[0]},${colors[1]})`, boxShadow: "0 2px 6px rgba(0,0,0,.2)" }}>
        {game ? (
          <img src={game.src} alt={game.name} draggable={false} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        ) : k === "tg" ? (
          <img src="/icons/telegram.jpg" alt="Telegram" draggable={false} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        ) : (
          <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}><SystemGlyph name={k} /></div>
        )}
      </div>
      {showLabel && iconName && <span style={{ maxWidth: size * 2.2, color: dark ? "#fff" : "#222", fontSize: Math.max(8, size * 0.2), lineHeight: 1.08, textAlign: "center", overflowWrap: "anywhere" }}>{iconName}</span>}
    </div>
  );
}

export function Phone({
  children,
  dark = false,
  w = 230,
  h = 470,
  style,
  className = "",
}: {
  children?: React.ReactNode;
  dark?: boolean;
  w?: number;
  h?: number;
  style?: React.CSSProperties;
  className?: string;
}) {
  return (
    <div
      className={className}
      style={{
        width: w,
        height: h,
        borderRadius: w * 0.17,
        padding: 8,
        background: dark ? "linear-gradient(145deg,#2b2b33,#0e0e12)" : "linear-gradient(145deg,#ffffff,#d9dbe3)",
        boxShadow: "0 22px 50px rgba(0,0,0,.35), inset 0 0 0 2px " + (dark ? "#444" : "#fff"),
        position: "relative",
        flexShrink: 0,
        ...style,
      }}
    >
      <div aria-hidden="true" style={{ position: "absolute", left: -3, top: 92, width: 4, height: 34, borderRadius: 3, background: dark ? "#57575e" : "#bfc1c8" }} />
      <div aria-hidden="true" style={{ position: "absolute", left: -3, top: 139, width: 4, height: 49, borderRadius: 3, background: dark ? "#57575e" : "#bfc1c8" }} />
      <div aria-hidden="true" style={{ position: "absolute", right: -3, top: 126, width: 4, height: 63, borderRadius: 3, background: dark ? "#57575e" : "#bfc1c8" }} />
      <div style={{ width: "100%", height: "100%", borderRadius: w * 0.13, overflow: "hidden", background: dark ? "#10131c" : "#f4f5fa", position: "relative" }}>
        <div aria-hidden="true" style={{ position: "absolute", left: 12, right: 12, top: 8, height: 14, zIndex: 6, display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 8, fontWeight: 700, color: dark ? "#fff" : "#151820" }}>
          <span>9:41</span>
          <svg viewBox="0 0 42 14" width="33" height="12" fill="none">
            <path d="M2 5.5a7.5 7.5 0 0 1 11 0M4.7 8a3.8 3.8 0 0 1 5.6 0M7.5 10.7h.1" stroke={dark ? "#fff" : "#151820"} strokeWidth="1.5" strokeLinecap="round" />
            <rect x="20" y="3" width="16" height="8" rx="2" stroke={dark ? "#fff" : "#151820"} strokeWidth="1.2" />
            <rect x="22" y="5" width="10" height="4" rx="1" fill={dark ? "#fff" : "#151820"} />
            <path d="M37.5 5.2v3.6" stroke={dark ? "#fff" : "#151820"} strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
        <div style={{ position: "absolute", top: 8, left: "50%", transform: "translateX(-50%)", width: w * 0.3, height: 16, borderRadius: 10, background: "#000", zIndex: 5 }} />
        {children}
      </div>
    </div>
  );
}

export function Grid({ keys, size = 40, dark, gap = 14, cols = 4, padding = "48px 14px 0" }: { keys: (string | [string, string])[]; size?: number; dark?: boolean; gap?: number; cols?: number; padding?: string }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols},1fr)`, gap, padding, justifyItems: "center" }}>
      {keys.map((k, i) => (Array.isArray(k) ? <AppIcon key={i} k={k[0]} label={k[1]} size={size} dark={dark} /> : <AppIcon key={i} k={k} size={size} dark={dark} />))}
    </div>
  );
}

export function TgMark({ size = 56 }: { size?: number }) {
  return (
    <img src="/icons/telegram.jpg" alt="Telegram" draggable={false} style={{ width: size, height: size, objectFit: "cover", borderRadius: size * 0.22, boxShadow: "0 3px 10px rgba(20,130,190,.22)", flexShrink: 0 }} />
  );
}

export function Bullet({ color, children, delay = 0 }: { color: string; children: React.ReactNode; delay?: number }) {
  return (
    <div className="fu" style={{ display: "flex", alignItems: "center", gap: 14, animationDelay: `${delay}s` }}>
      <div style={{ width: 16, height: 16, borderRadius: "50%", background: color, flexShrink: 0 }} />
      <span style={{ fontSize: 25, fontWeight: 600, color: "#1d1d2b", lineHeight: 1.2 }}>{children}</span>
    </div>
  );
}

export function Card({ children, style, className = "" }: { children: React.ReactNode; style?: React.CSSProperties; className?: string }) {
  return (
    <div className={className} style={{ background: "#fff", borderRadius: 26, padding: 28, boxShadow: "0 18px 44px rgba(60,40,120,.2)", ...style }}>
      {children}
    </div>
  );
}
